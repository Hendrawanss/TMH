<?php

namespace App\Http\Controllers;

use App\Interfaces\CheckInputRepositoryInterface;
use Illuminate\Http\Request;

class InputCheckController extends Controller
{

    private CheckInputRepositoryInterface $checkInputRepositoryInterface;

    public function __construct(CheckInputRepositoryInterface $checkInputRepositoryInterface)
    {
        $this->checkInputRepositoryInterface = $checkInputRepositoryInterface;
    }

    public function index() {
        return view('pages.check.index');
    }

    public function process(Request $request) {
        // return $this->checkInputRepositoryInterface->selectionChar($request->input1,$request->input2);
        return view('pages.check.result', [
            "data" => $this->checkInputRepositoryInterface->selectionChar($request->input1,$request->input2)
        ]);
    }
}
