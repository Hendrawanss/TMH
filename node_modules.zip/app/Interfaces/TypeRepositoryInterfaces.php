<?php

namespace App\Interfaces;

interface TypeRepositoryInterfaces {
    public function getAllTypes();
}