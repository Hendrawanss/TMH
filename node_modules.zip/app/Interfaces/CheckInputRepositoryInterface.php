<?php

namespace App\Interfaces;

interface CheckInputRepositoryInterface {
    public function selectionChar($string1,$string2);
}