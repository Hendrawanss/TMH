<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="py-12">
        <div class="bg-white p-5 rounded-lg shadow-lg w-full max-w-2xl mx-auto">
            <header class="border-b border-gray-100">
                <h2 class="pb-3 font-semibold text-gray-800">Check Result</h2>
            </header>
            
            <div class="grid mb-3">
                <label class="mb-3">Persentase karakter dari input pertama ada di input kedua adalah <label class="text-lg font-bold"><?php echo e($data["percentage"]); ?></label></label>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\hashmicro\resources\views/pages/check/result.blade.php ENDPATH**/ ?>