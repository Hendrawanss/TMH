<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <form action="<?php echo e(route('order.update', ['order' => $transaction->id])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field("PUT"); ?>
            <div class="bg-white p-5 rounded-lg shadow-lg w-full max-w-2xl mx-auto">
                <header class="border-b border-gray-100">
                    <h2 class="pb-3 font-semibold text-gray-800">Edit Order</h2>
                </header>
                <div class="my-2">
                    <x.label>Customer</x.label>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.label','data' => ['class' => 'text-xl font-bold']]); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-xl font-bold']); ?><?php echo e($transaction->customer->name); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
                <div>
                    <x.label>Item</x.label>
                    <div class="flex align-middle flex-row justify-between font-bold">
                        <div class="p-2">
                            Item Name
                        </div>
                        <div class="p-2">
                            Price
                        </div>
                        <div class="p-2">
                            Total Order
                        </div>
                    </div>
                    <?php $__currentLoopData = $transaction->detail_transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex align-middle flex-row justify-between">
                            <div class="p-2">
                                <?php echo e($dt->menu->name); ?>

                            </div>
                            <div class="p-2">
                                Rp <?php echo e(number_format($dt->menu->price,0,',','.')); ?>

                            </div>
                            <div class="p-2">
                                <input type="hidden" name="barang[<?php echo e($dt->menu->id); ?>][menu_id]" value="<?php echo e($dt->menu->id); ?>" >
                                <input type="number" min="0" name="barang[<?php echo e($dt->menu->id); ?>][total_item]" value="<?php echo e($dt->total_item); ?>" >
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="text-right mt-3">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => []]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        <?php echo e(__('Update')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\hashmicro\resources\views/pages/order/edit.blade.php ENDPATH**/ ?>