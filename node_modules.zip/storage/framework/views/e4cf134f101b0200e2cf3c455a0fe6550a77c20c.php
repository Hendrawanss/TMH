<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="w-full max-w-2xl mx-auto">
            <div class="m-3 text-right">
                <a href="<?php echo e(route('order.create')); ?>" class="p-2 rounded-md shadow-md bg-lime-500 text-white hover:bg-lime-600">Create</a>
            </div>
            <div class="w-full max-w-2xl mx-auto bg-white shadow-lg rounded-md border border-gray-200">
                <header class="px-5 py-4 border-b border-gray-100">
                    <h2 class="pl-3 font-semibold text-gray-800">Orders</h2>
                </header>
                <div class="p-3">
                    <div class="overflow-x-auto">
                        <table class="table-auto w-full">
                            <thead class="text-xs font-semibold uppercase text-gray-400 bg-gray-50">
                                <tr>
                                    <th class="p-2 whitespace-nowrap">
                                        <div class="font-semibold text-left">Customer Name</div>
                                    </th>
                                    <th class="p-2 whitespace-nowrap">
                                        <div class="font-semibold text-left">Order</div>
                                    </th>
                                    <th class="p-2 whitespace-nowrap">
                                        <div class="font-semibold text-left">Item Total</div>
                                    </th>
                                    <th class="p-2 whitespace-nowrap">
                                        <div class="font-semibold text-center">Actions</div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="text-sm divide-y divide-gray-100">
                                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="p-2 whitespace-nowrap">
                                            <div class="font-medium text-gray-800"><?php echo e($t->customer->name); ?></div>
                                        </td>
                                        <td class="p-2 whitespace-nowrap">
                                            <?php $__currentLoopData = $t->detail_transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="text-left"><?php echo e($detail->menu->name); ?></div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td class="p-2 whitespace-nowrap">
                                            <?php $__currentLoopData = $t->detail_transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="text-left font-medium text-green-700"><?php echo e($detail->total_item); ?></div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td class="whitespace-nowrap grid grid-cols-2">
                                            <div class="mt-2">
                                                <a href="<?php echo e(route('order.edit', [ 'order' => $t->id])); ?>" class="p-2 rounded-md shadow-md bg-blue-300 text-white hover:bg-blue-400">Edit</a>
                                            </div>
                                            <div>
                                                <form action="<?php echo e(route('order.destroy', [ 'order' => $t->id])); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button class="p-2 rounded-md shadow-md bg-red-300 text-white hover:bg-red-400" type="submit">Delete</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\hashmicro\resources\views/pages/order/index.blade.php ENDPATH**/ ?>